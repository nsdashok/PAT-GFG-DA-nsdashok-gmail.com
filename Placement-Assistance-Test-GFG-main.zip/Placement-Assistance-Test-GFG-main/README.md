# Placement-Assistance-Test-GFG
This repository is having all the codes and assignment of Placement Assistance Test happened so far in association with GFG

1. Download the whole repository
2. Use the Data Analysis folder for Data Anlaysis Assignment and Machine Learning Folder for ML Assignment
3. Perform the Assignment
4. Upload the Needed files as mentioned in the Video
5. Submit the link of repository that you've made in the google form
6. Make sure the repository is public.

Best of Luck
